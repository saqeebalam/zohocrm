package com.zoho.util;

public interface EmailService {
	/**
	 *
	 * @implNote responcible for sending email
	 * @param to
	 * @param subject
	 * @param message
	 */
	public void sendEmail(String to,String subject,String message);
}
