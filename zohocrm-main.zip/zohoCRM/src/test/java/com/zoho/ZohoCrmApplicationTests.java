package com.zoho;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZohoCrmApplicationTests {

	@Test
	void contextLoads() {
	}

}
